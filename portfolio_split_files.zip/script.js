const revealElements = document.querySelectorAll(".reveal");

    function revealOnScroll() {
      revealElements.forEach((element) => {
        const windowHeight = window.innerHeight;
        const elementTop = element.getBoundingClientRect().top;
        const revealPoint = 120;

        if (elementTop < windowHeight - revealPoint) {
          element.classList.add("active");
        }
      });
    }

    window.addEventListener("scroll", revealOnScroll);
    window.addEventListener("load", revealOnScroll);

    document.querySelector("form").addEventListener("submit", function(e) {
      e.preventDefault();
      alert("Thank you! Your message has been submitted.");
      this.reset();
    });

    const lightbox = document.getElementById("lightbox");
    const lightboxText = document.getElementById("lightboxText");

    document.querySelectorAll(".gallery-item").forEach((item) => {
      item.addEventListener("click", () => {
        lightboxText.textContent = item.dataset.label;
        lightbox.classList.add("active");
      });
    });

    document.querySelector(".close-lightbox").addEventListener("click", () => {
      lightbox.classList.remove("active");
    });

    lightbox.addEventListener("click", (e) => {
      if (e.target === lightbox) {
        lightbox.classList.remove("active");
      }
    });
